function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220,200,00);
  ellipse(50,46,80,80);
  fill(100)
  triangle(250,20,58,200,300,100);
  fill(200,400,500); 
}