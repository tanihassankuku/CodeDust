//group:1
function setup() {
  createCanvas(300, 300);
}

function draw() {
  background(200,150,200);
  quad( 38,31,86,20,69,63,30,76);
  ellipse(10,010,10);
  fill(100,300,500);
  line(0,50,400,300);

}